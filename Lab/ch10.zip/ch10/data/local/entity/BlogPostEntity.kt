package com.example.blogapp.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey


data class BlogPostEntity(
    val id: Long = 0,
    val title: String,
    val content: String,
    val author: String,
    val imageUri: String?,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)