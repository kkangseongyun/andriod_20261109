package com.example.blogapp.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.blogapp.data.local.entity.BlogPostEntity
import kotlinx.coroutines.flow.Flow


interface BlogPostDao {

    fun getAllPosts(): Flow<List<BlogPostEntity>>

    suspend fun getPostById(id: Long): BlogPostEntity?

    suspend fun insertPost(post: BlogPostEntity): Long

    suspend fun updatePost(post: BlogPostEntity)

    suspend fun deletePostById(id: Long)
}