plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.androidlab"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.androidlab"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = true
                packageScope = setOf("androidx.**", "kotlin.**", "kotlinx.**")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    //viewBinding 이용 선언, 선언만으로.. layout xml 파일 단위로 xxxBinding 클래스 자동 작성..
    //build.gradle.kts 파일 변경되면, 변경사항 적용하기 위해서 꼭 Sync Now 클릭..
    viewBinding.enable = true
}

dependencies {
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
}