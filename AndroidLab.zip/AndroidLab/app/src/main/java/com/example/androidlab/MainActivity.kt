package com.example.androidlab

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.androidlab.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

//    lateinit var button: Button
//    lateinit var editView: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

//        //화면 출력.. 뷰 객체 생성 완료(inflate)
//        setContentView(R.layout.activity_main)
//        //필요한 뷰 객체 획득..
//        button = findViewById(R.id.button)
//        editView = findViewById(R.id.editView)
//        //이벤트 등록..
//        button.setOnClickListener {
//            val data = editView.text.toString()
//            Log.d("TAG", data)
//        }

        //viewBinding................................
        //XXXBinding 에 inflate 명령내려야 한다.
        val binding = ActivityMainBinding.inflate(layoutInflater)
        //화면 출력..
        setContentView(binding.root)

        binding.button.setOnClickListener {
            val data = binding.editView.text.toString()
            Log.d("TAG", data)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

}