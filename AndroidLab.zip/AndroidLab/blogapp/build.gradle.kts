plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.blogapp"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.blogapp"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = true
                packageScope = setOf("androidx.**", "kotlin.**", "kotlinx.**")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
//    implementation("androidx.core:core-ktx:1.10.1")
    implementation(libs.androidx.lifecycle.runtime.ktx)
    testImplementation(libs.junit)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)

    //라이브러리 등록의 기본은..
    //implementation("group_id:artifact_id:version")
    //하나의 프로젝트내에 여러 모듈, 여러 모듈에 공통 적용 라이브러리, 버전관리 편의성을 위해서..
    //라이브러리 등록을 libs.versions.toml 에 하고.. 해당 라이브러리가 필요한 모듈에서는 링크만 걸어서 사용
    //==>버전을 하나의 파일에서 관리하게..

    //androidx 라이브러리를 이용할 때
    //artifact id 가 aaa(자바), aaa-ktx(코틀린), 동일 라이브러리다.
    //ktx - 코틀린으로 개발할 때 자바 라이브러리 이용 가능하지만 약간의 불편함을 없애기 위해 만들어준..

    //라이브러리 등록,  sync now 순간 download, 빌드시에 이곳에 선언된 라이브러리만 적용..
    implementation("androidx.compose.material:material-icons-extended-android:1.7.8")
    implementation("androidx.constraintlayout:constraintlayout-compose:1.1.2")
    //이미지 핸들링 라이브러리..
    //glide, colil
    implementation("io.coil-kt:coil-compose:2.7.0")
    //navigation
    implementation("androidx.navigation:navigation-compose:2.9.8")
}