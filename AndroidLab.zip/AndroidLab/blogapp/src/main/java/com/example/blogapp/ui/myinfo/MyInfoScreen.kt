package com.example.blogapp.ui.myinfo

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import kotlinx.coroutines.launch

@Composable
fun MyInfoScreen(
    onBack: () -> Unit
) {

    //스낵바를 띄우기 위한 상태.. 상태 변경으로. 화면 재구성.. 스낵바 출력되게..
    //스낵바는 일회성이어서 화면회전시에 상태가 유지될 필요는 없어 보인다..
    val snackbarHostState = remember { SnackbarHostState() }

    //coroutine : 비동기 흐름..
    //coroutineScope : coroutine 이 실행되는 영역.. 모든 coroutine은 scope가 먼저 준비되어야 하고..
    //그 scope 내에서 실행..
    //snackbar를 띄우기 위한 함수는 suspend 로 선언되어 있고, suspend 함수는 coroutine 내에서만 호출이 가능해서
    val scope = rememberCoroutineScope()

    //화면의 기본 구조 구성해주는. 컴포저블..
    //snackbar가 화면의 하단에서 출력.. Scaffold 의 화면 구성 정보로 준비되어 있다..
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState)}
    ) { innerPadding ->//Scaffold 는 화면의 기본구조.. 항상 매개변수로 화면의 padding 값을 받아들이게 되어 있다.
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("MyInfoScreen!")
            Button(
                onClick = onBack
            ) {
                Text("Go Back")
            }
            Button(
                onClick = {
                    //showSnackbar - suspend function
                    scope.launch {//launch : coroutine builder. 새로운 비동기 흐름을 만들고 만들자 마자 실행
                        snackbarHostState.showSnackbar("저장되었습니다.")
                    }
                }
            ) {
                Text("Snackbar")
            }

        }
    }



}