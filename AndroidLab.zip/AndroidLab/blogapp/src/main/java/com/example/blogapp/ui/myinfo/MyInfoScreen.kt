package com.example.blogapp.ui.myinfo

import android.util.Log
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun MyInfoScreen(
    onBack: () -> Unit
) {

    //스낵바를 띄우기 위한 상태.. 상태 변경으로. 화면 재구성.. 스낵바 출력되게..
    //스낵바는 일회성이어서 화면회전시에 상태가 유지될 필요는 없어 보인다..
    val snackbarHostState = remember { SnackbarHostState() }

    //coroutine : 비동기 흐름..
    //coroutineScope : coroutine 이 실행되는 영역.. 모든 coroutine은 scope가 먼저 준비되어야 하고..
    //그 scope 내에서 실행..
    //snackbar를 띄우기 위한 함수는 suspend 로 선언되어 있고, suspend 함수는 coroutine 내에서만 호출이 가능해서
    val scope = rememberCoroutineScope()

    var email by rememberSaveable { mutableStateOf("") }

    fun onEditEmailChange(value: String){
        email = value
    }

    fun saveEmail(){
        scope.launch {
            Log.d("TAG", "이메일이 저장되었습니다.")
        }
    }

    //화면의 기본 구조 구성해주는. 컴포저블..
    //snackbar가 화면의 하단에서 출력.. Scaffold 의 화면 구성 정보로 준비되어 있다..
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState)}
    ) { innerPadding ->//Scaffold 는 화면의 기본구조.. 항상 매개변수로 화면의 padding 값을 받아들이게 되어 있다.
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
//            horizontalAlignment = Alignment.CenterHorizontally,
//            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "프로필 설정",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = email,
                onValueChange = ::onEditEmailChange,
                label = { Text("이메일") },
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("example@email.com") }
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "현재 저장된 이메일: ${if (email.isBlank()) "없음" else email}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    saveEmail()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("저장")
            }

        }
    }



}