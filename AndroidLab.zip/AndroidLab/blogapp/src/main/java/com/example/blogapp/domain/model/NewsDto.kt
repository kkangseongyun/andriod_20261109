package com.example.blogapp.domain.model

//서버에서 넘어오는 데이터..
data class News(
    val id: Long = 0,
    val author: String? = null,
    val title: String? = null,
    val description: String? = null,
    val urlToImage: String? = null,
    val publishedAt: String? = null
)

data class Page(
    val articles: List<News>? = null
)