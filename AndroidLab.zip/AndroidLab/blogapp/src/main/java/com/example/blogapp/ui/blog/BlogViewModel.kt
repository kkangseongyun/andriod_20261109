package com.example.blogapp.ui.blog

import androidx.lifecycle.ViewModel
import com.example.blogapp.domain.model.BlogPost
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@HiltViewModel
class BlogViewModel @Inject constructor(): ViewModel() {
    //블로그 데이터 전체..
    private val _posts = MutableStateFlow(mutableListOf<BlogPost>())
    val posts: StateFlow<List<BlogPost>> = _posts.asStateFlow()

    //선택된 블로그 글 데이터..
    private val _selectedPost = MutableStateFlow<BlogPost?>(null)
    val selectedPost: StateFlow<BlogPost?> = _selectedPost.asStateFlow()

    fun loadPost(id: Long){
        _selectedPost.value = _posts.value.find { it.id == id }
    }

    fun savePost(id: Long, title: String, content: String, imageUri: String?){
        val index = _posts.value.indexOfFirst { it.id == id }

        if(index != -1){//매개변수의 id 에 해당되는 데이터가 있다. ==> update
            val existing = _posts.value[index]
            _posts.value[index] = existing.copy(
                title = title,
                content = content,
                imageUri = imageUri
            )
        }else {//id 에 해당되는 데이터 없다. ==>create
            _posts.value.add(
                BlogPost(
                    id = _posts.value.size.toLong() + 1,
                    title = title,
                    content = content,
                    author = "author",
                    imageUri = imageUri
                )
            )
        }
    }

    fun deletePost(id: Long){
        _posts.value.removeAll { it.id == id }
    }

}