package com.example.blogapp.ui.blog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.blogapp.data.preferences.UserPreferences
import com.example.blogapp.data.repository.BlogRepository
import com.example.blogapp.domain.model.BlogPost
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class BlogViewModel @Inject constructor(
    private val userPreferences: UserPreferences,
    private val repository: BlogRepository
): ViewModel() {
    //블로그 데이터 전체..
//    private val _posts = MutableStateFlow(mutableListOf<BlogPost>())
//    val posts: StateFlow<List<BlogPost>> = _posts.asStateFlow()

    val posts: StateFlow<List<BlogPost>> = repository.allPosts.stateIn(
        scope = viewModelScope,
        //최초의 구독자가 나타나면 움직여러.. 마지막 구독자가 사라진후 5초 후 멈추어라..
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    //선택된 블로그 글 데이터..
    private val _selectedPost = MutableStateFlow<BlogPost?>(null)
    val selectedPost: StateFlow<BlogPost?> = _selectedPost.asStateFlow()

    fun loadPost(id: Long){
//        _selectedPost.value = _posts.value.find { it.id == id }
        viewModelScope.launch {
            val post = repository.getPostById(id)
            _selectedPost.value = post
        }
    }

    fun savePost(id: Long, title: String, content: String, imageUri: String?){
//        val index = _posts.value.indexOfFirst { it.id == id }
//
//        if(index != -1){//매개변수의 id 에 해당되는 데이터가 있다. ==> update
//            val existing = _posts.value[index]
//            _posts.value[index] = existing.copy(
//                title = title,
//                content = content,
//                imageUri = imageUri
//            )
//        }else {//id 에 해당되는 데이터 없다. ==>create
//            _posts.value.add(
//                BlogPost(
//                    id = _posts.value.size.toLong() + 1,
//                    title = title,
//                    content = content,
//                    author = "author",
//                    imageUri = imageUri
//                )
//            )
//        }

        viewModelScope.launch {
            if (title.isBlank()) return@launch
            val author = userPreferences.email.first().ifBlank { "Unknown" }
            if (id > 0) {
                repository.updatePost(

                    BlogPost(
                        id = id,
                        title = title,
                        content = content,
                        author = author,
                        imageUri = imageUri,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            } else {
                repository.insertPost(
                    BlogPost(
                        title = title,
                        content = content,
                        author = author,
                        imageUri = imageUri
                    )
                )
            }
        }
    }

    fun deletePost(id: Long){
//        _posts.value.removeAll { it.id == id }
        viewModelScope.launch {
            //room 의 dao 함수는 main thread가 아닌 background 에서 실행되어야 해서..
            repository.deletePost(id)
        }
    }

}