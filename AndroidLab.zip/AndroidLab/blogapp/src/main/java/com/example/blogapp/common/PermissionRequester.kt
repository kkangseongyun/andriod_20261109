package com.example.blogapp.common

import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

//앱에 등록되는 퍼미션이 많다. 많은 부분 유저에게 허락받아야 한다. 공통코드가 이곳저곳에 작성되어야 해서..
@Composable
fun permissionRequester(
    permission: String,
    onPermissionGranted: () -> Unit = {},//허락 상태에서 실행할 함수..
    onPermissionDenied: () -> Unit = {}
) {
    val context = LocalContext.current

    //퍼미션 조정 다이얼로그를 띄우기 위한 런처.. 콜백 포함..
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted -> //callback..
        if(isGranted){
            onPermissionGranted()
        }else {
            onPermissionDenied()
        }
    }

    LaunchedEffect(permission) {
        //퍼미션 상태 파악..
        val isGranted = ContextCompat.checkSelfPermission(context, permission) ==
                PackageManager.PERMISSION_GRANTED
        if(isGranted){
            onPermissionGranted()
        }else {
            permissionLauncher.launch(permission)
        }
    }
}