package com.example.blogapp.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

//room 으로 table과 매핑될 엔터티 클래스
//우리의 경우는 domain.model 의 BlogPost와 동일하지만 일반적으로 다른 부분이 있어 domain model과 별도로
//선언
@Entity(tableName = "blog_posts")
data class BlogPostEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val author: String,
    val imageUri: String?,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)