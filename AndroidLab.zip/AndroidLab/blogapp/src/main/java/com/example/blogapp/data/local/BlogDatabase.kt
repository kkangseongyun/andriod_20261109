package com.example.blogapp.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.blogapp.data.local.dao.BlogPostDao
import com.example.blogapp.data.local.entity.BlogPostEntity

//entity, dao 등록 RoomDatabase

@Database(
    entities = [BlogPostEntity::class],
    version = 1,
    exportSchema = false
)
abstract class BlogDatabase: RoomDatabase()  {
    //추상형으로.. dao 획득 함수 나열..
    abstract fun blogPostDao(): BlogPostDao
}