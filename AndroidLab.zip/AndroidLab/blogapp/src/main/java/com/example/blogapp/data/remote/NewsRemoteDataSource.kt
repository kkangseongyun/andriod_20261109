package com.example.blogapp.data.remote

import com.example.blogapp.domain.model.Page
import javax.inject.Inject

class NewsRemoteDataSource @Inject constructor(
    private val apiService: NewsApiService
) {
    //interface 함수 호출해서 실제 네트워킹 시도..
    suspend fun getNewsList(query: String, apiKey: String, page: Long, pageSize: Int): Page =
        apiService.getList(query, apiKey, page, pageSize)
}