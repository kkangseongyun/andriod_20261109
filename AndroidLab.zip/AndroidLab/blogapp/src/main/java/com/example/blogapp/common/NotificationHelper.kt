package com.example.blogapp.common

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.blogapp.receiver.MyReceiver


fun createNotificationChannel(context: Context) {
    //26 이전에는 알림에 채널 개념이 없었다. 26 이상에서는 채널 개념이 적용되지 않으면 알림이 안뜬다.
    //Build.VERSION.SDK_INT : 앱이 실행되는 유저 폰의 api level
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            "default_channel",
            "기본 알림",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "앱의 기본 알림 채널입니다."
        }
        //채널을 하나 준비하고. 시스템에 등록..
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }
}

fun showNotification(context: Context){
    //채널준비..
    createNotificationChannel(context)

    //알림 터치시에 이벤트 처리..
    //우리의 Receiver를 실행시키고자 한다.
    //인텐트를 준비해야 한다..
    //인텐트는 우리가 준비하지만 인텐트를 우리가 발생시킬 수 없다. 시스템 영역에서 발생하는 이벤트이다.
    //알림 정보로 이벤트 의뢰..
    val intent = Intent(context, MyReceiver::class.java)
    val pIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)

    val notification = NotificationCompat.Builder(context, "default_channel")
        .setSmallIcon(android.R.drawable.ic_notification_overlay)
        .setContentTitle("메시지")
        .setContentText("안녕하세요.")
        .setContentIntent(pIntent)
        .build()

    //발생..
    val manager = context.getSystemService(NotificationManager::class.java)
    manager.notify(11, notification)
}




