package com.example.blogapp.ui.blog.detail

import android.transition.CircularPropagation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.blogapp.R

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA)
    return sdf.format(Date(timestamp))
}

@Composable
fun BlogDetailScreen(
    onBack: () -> Unit,
) {
    ConstraintLayout(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 60.dp)
            .verticalScroll(rememberScrollState())
    ) {
        //참조 선언..
        val (image, title, authorRow, updatedText, divider, content) = createRefs()
        //coil 에서 제공하는 이미지 컴포저블..
        //기본은 AsyncImage + 로딩/에러
        SubcomposeAsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(R.drawable.main_swiss)//리소스 이미지 이외에 네트웍/파일 이미지도 가능..
                .crossfade(true)//이미지 로딩 완료시 출력되때 애니메이션 효과(fade)
                .build(),
            contentDescription = "타이틀",
            contentScale = ContentScale.Crop,//이미지의 자체 사이즈 - 화면 출력 사이즈, 대부분 맞지 않다..
            //어떻게 출력할 것인가? 화면 사이즈에 비율을 유지한 상태에서 꽉 들어차게 맞추고 남는 부분은 버려라..
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .constrainAs(image){
                    top.linkTo(parent.top)
                },
            loading = {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()//빙빙빙..
                }
            }

        )

        Text(
            text = "타이틀",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 20.dp)
                .constrainAs(title){
                    top.linkTo(image.bottom)
                }
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .constrainAs(authorRow) {
                    top.linkTo(title.bottom)
                }
        ) {
            Text(
                text = "작성자: Unknown" ,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = " · ",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = formatDate(System.currentTimeMillis()),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // 수정일 (조건부)
        Text(
            text = "수정됨: ",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .constrainAs(updatedText) {
                    top.linkTo(authorRow.bottom)
                }
        )

        // 구분선
        HorizontalDivider(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .constrainAs(divider) {
                    top.linkTo(
                        updatedText.bottom
                    )
                }
        )

        // 본문
        Text(
            text = "(내용 없음)",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, bottom = 20.dp)
                .constrainAs(content) {
                    top.linkTo(divider.bottom)
                }
        )




    }
}