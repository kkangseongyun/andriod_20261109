package com.example.blogapp.ui.blog.detail

import android.transition.CircularPropagation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.core.net.toUri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.blogapp.R
import com.example.blogapp.ui.blog.BlogViewModel

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA)
    return sdf.format(Date(timestamp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlogDetailScreen(
    viewModel: BlogViewModel,
    onBack: () -> Unit,
    postId: Long,
    onEdit: () -> Unit,//edit 화면으로 전환을 목적으로 호출..
    onDelete: () -> Unit,//글 삭제 후 화면 전환을 목적으로 호출..
) {

    //remember : 일반적으로는 상태를 선언할 때 같이 사용되지만..
    //상태와 별개로.. 이 함수가 재구성될때 다시 실행될 필요가 없는 부분을 감싸는 역활로도 사용가능..
    //LaunchedEffect와 동일해 보이지만 역활이 다르다..
    //LaunchedEffect은 비동기로 실행되면서 특정 로직을 반복적으로 실행시킬 필요가 없을 때..
    //remember { } 데이터가 매번 획득될 필요가 없는 경우..
//    val post = remember(postId) {
//        posts.find { it. id == postId}
//    }

    val selectedPost by viewModel.selectedPost.collectAsStateWithLifecycle()

    LaunchedEffect(postId) {
        viewModel.loadPost(postId)
    }

    //화면에 다이얼로그 띄우고자 한다. 다이얼로그도 화면이다.
    //다이얼로그가 뜨는 화면, 안뜨는 화면, 화면이 재구성 되어야 한다. ==>상태..
    var showDeleteDialog by remember { mutableStateOf(false) }

    if(showDeleteDialog){
        //전형적인 다이얼로그 UI 제공..
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false},//dialog outside 터치시에 다이얼로그 닫기게?
            title = { Text("게시물 삭제")},
            text = { Text("삭제하시겠습니까?")},
            //필수..
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    viewModel.deletePost(postId)
                    onDelete()
                }) {
                    Text("삭제")
                }
            },
            //optional
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("취소")
                }
            },
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("게시물 상세") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "뒤로가기")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        onEdit()
                    }) {
                        Icon(Icons.Default.Edit, contentDescription = "수정")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "삭제",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { innerPadding ->

        val post = selectedPost

        if (post == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            ConstraintLayout(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
            ) {

                val (image, title, authorRow, updatedText, divider, content) = createRefs()

                // 변경 .........
                if (post.imageUri != null) {
                    SubcomposeAsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(post.imageUri.toUri())//변경................
                            .crossfade(true)
                            .build(),
                        contentDescription = post.title,//변경................
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .constrainAs(image) {
                                top.linkTo(parent.top)
                                start.linkTo(parent.start)
                                end.linkTo(parent.end)
                            },
                        loading = {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator()
                            }
                        }
                    )
                }


                Text(
                    text = post.title,//변경................
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 20.dp, top = 20.dp)
                        .constrainAs(title) {
                            top.linkTo(
                                //변경................
                                if (post.imageUri != null) image.bottom else parent.top
                            )
                            start.linkTo(parent.start)
                            end.linkTo(parent.end)
                        }
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .constrainAs(authorRow) {
                            top.linkTo(title.bottom)
                            start.linkTo(parent.start)
                            end.linkTo(parent.end)
                        }
                ) {
                    Text(
                        text = "작성자: ${post.author.ifBlank { "Unknown" }}" ,//변경................
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = " · ",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatDate(System.currentTimeMillis()),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                //변경.........
                if (post.updatedAt != post.createdAt) {
                    // 수정일 (조건부)
                    Text(
                        text = "수정됨: ${formatDate(post.updatedAt)}",//변경............
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                            .constrainAs(updatedText) {
                                top.linkTo(authorRow.bottom)
                                start.linkTo(parent.start)
                            }
                    )
                }

                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                        .constrainAs(divider) {
                            top.linkTo(
                                //변경............
                                if (post.updatedAt != post.createdAt) updatedText.bottom
                                else authorRow.bottom
                            )
                            start.linkTo(parent.start)
                            end.linkTo(parent.end)
                        }
                )

                Text(
                    text = post.content.ifBlank { "(내용 없음)" },//변경............
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 20.dp, bottom = 20.dp)
                        .constrainAs(content) {
                            top.linkTo(divider.bottom)
                            start.linkTo(parent.start)
                            end.linkTo(parent.end)
                        }
                )
            }
        }
    }


}