package com.example.blogapp.ui.myinfo

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MyInfoViewModel(
    application: Application
): AndroidViewModel(application) {
    //여러 composable 을 위한 상태 데이터 발생 flow
    //MutableStateFlow : coroutine - flow
    private val _email = MutableStateFlow("")

    //외부에서 이용하는 데이터.. StateFlow : 데이터 참조만 된다. 발생은 안된다.
    val email: StateFlow<String> = _email.asStateFlow()

    fun saveEmail(email: String){
        //B/L 실행시키고..
        _email.value = email.trim()//데이터 발행.. 이 데이터를 구독하는(composable)모든 곳에 전달..
    }
}