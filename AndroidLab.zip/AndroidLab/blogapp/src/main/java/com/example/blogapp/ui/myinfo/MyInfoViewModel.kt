package com.example.blogapp.ui.myinfo

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.blogapp.data.preferences.UserPreferences
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MyInfoViewModel @Inject constructor(
    private val userPreferences: UserPreferences
): ViewModel() {
    //여러 composable 을 위한 상태 데이터 발생 flow
    //MutableStateFlow : coroutine - flow
//    private val _email = MutableStateFlow("")
//
//    //외부에서 이용하는 데이터.. StateFlow : 데이터 참조만 된다. 발생은 안된다.
//    val email: StateFlow<String> = _email.asStateFlow()

    //coroutine의 flow는 cold stream - 어디선가 구독자가 나타나야 작업을 시작하고
    //여러 구독자가 나오면 개별적으로 작업을 따로 실행.
    //==>cold stream 을 hot stream으로 변형..
    //구독자가 없어도 실행. 데이터 발생. 여러 구독자가 동일 데이터
    val email: StateFlow<String> = userPreferences.email.stateIn(
        scope = viewModelScope,
        //최초의 구독자가 나타나면 움직여러.. 마지막 구독자가 사라진후 5초 후 멈추어라..
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ""
    )

    fun saveEmail(email: String){
        //B/L 실행시키고..
//        _email.value = email.trim()//데이터 발행.. 이 데이터를 구독하는(composable)모든 곳에 전달..
        viewModelScope.launch {
            userPreferences.saveEmail(email.trim())
        }
    }
}