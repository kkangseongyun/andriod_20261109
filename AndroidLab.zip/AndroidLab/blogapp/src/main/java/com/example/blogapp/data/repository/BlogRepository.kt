package com.example.blogapp.data.repository

import com.example.blogapp.data.local.dao.BlogPostDao
import com.example.blogapp.data.local.entity.BlogPostEntity
import com.example.blogapp.domain.model.BlogPost
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

//hilt에 의해 객체가 관리..
//생성자 매개변수에 @Inject 추가만으로 이 객체는 hilt가 생성 관리된다.
//생성자를 우리가 호출하지 않는다. 생성자 매개변수가 있다.
//매개변수도 Hilt 의 @Inject로 등록되어 있어야 한다.
//ViewModel에서 B/L을 위해 호출되는 함수..
//interface다.
//==>Module
@Singleton
class BlogRepository @Inject constructor(
    private val dao: BlogPostDao
) {

    //Entity Data <-> domain Data
    private fun BlogPostEntity.toDomain() = BlogPost(
        id = id,
        title = title,
        content = content,
        author = author,
        imageUri = imageUri,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun BlogPost.toEntity() = BlogPostEntity(
        id = id,
        title = title,
        content = content,
        author = author,
        imageUri = imageUri,
        createdAt = createdAt,
        updatedAt = updatedAt
    )


    val allPosts: Flow<List<BlogPost>> = dao.getAllPosts().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun getPostById(id: Long): BlogPost? =
        dao.getPostById(id)?.toDomain()


    suspend fun insertPost(post: BlogPost): Long =
        dao.insertPost(post.toEntity())


    suspend fun updatePost(post: BlogPost) =
        dao.updatePost(post.toEntity())


    suspend fun deletePost(id: Long) =
        dao.deletePostById(id)
}