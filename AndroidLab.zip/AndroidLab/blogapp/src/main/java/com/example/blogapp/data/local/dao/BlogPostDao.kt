package com.example.blogapp.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.blogapp.data.local.entity.BlogPostEntity
import kotlinx.coroutines.flow.Flow

//dbms시 호출할 함수가 선언되어 있는 인터페이스 혹은 추상클래스
//함수만 선언하면 어노테이션을 보고 dbms가능 코드가 알아서 만들어진다.

@Dao
interface BlogPostDao {

    @Query("SELECT * FROM blog_posts ORDER BY createdAt DESC")
    fun getAllPosts(): Flow<List<BlogPostEntity>>

    //SQL문에 :a 는 a라는 매개변수..
    @Query("SELECT * FROM blog_posts WHERE id = :id")
    suspend fun getPostById(id: Long): BlogPostEntity?

    @Insert
    suspend fun insertPost(post: BlogPostEntity): Long

    @Update
    suspend fun updatePost(post: BlogPostEntity)

    @Query("DELETE FROM blog_posts WHERE id = :id")
    suspend fun deletePostById(id: Long)
}