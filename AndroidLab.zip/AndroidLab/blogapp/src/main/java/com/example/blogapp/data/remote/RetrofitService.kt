package com.example.blogapp.data.remote

import com.example.blogapp.domain.model.Page
import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url

interface NewsApiService {

    @GET("/v2/everything")
    suspend fun getList(
        @Query("q") q: String?,//검색어..
        @Query("apiKey") apiKey: String?,
        @Query("page") page: Long,
        @Query("pageSize") pageSize: Int
    ): Page
}