package com.example.blogapp.di

import android.content.Context
import androidx.room.Room
import com.example.blogapp.data.local.BlogDatabase
import com.example.blogapp.data.local.dao.BlogPostDao
import com.example.blogapp.data.remote.NewsApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import jakarta.inject.Singleton
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

//Hilt에 @Inject로 등록할 수 없는 객체를 직접 준비/명시하기 위해서..
//라이브러리 객체 직접 준비
//인터페이스 타입, 상위 타입으로 이용되는 클래스 명시..
@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): BlogDatabase =
        //앱이 실행되면서 최초에 한번, singleton으로 room database객체가 준비되어야..
        Room.databaseBuilder(
            context,
            BlogDatabase::class.java,
            "blog_database"
        ).build()

    @Provides
    @Singleton
    fun provideBlogPostDao(db: BlogDatabase): BlogPostDao = db.blogPostDao()


    @Provides
    @Singleton
    fun provideRetrofit(): Retrofit =
        Retrofit.Builder()
            .baseUrl("https://newsapi.org")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    @Provides
    @Singleton
    fun provideNewsApiService(retrofit: Retrofit): NewsApiService =
        retrofit.create(NewsApiService::class.java)
}
