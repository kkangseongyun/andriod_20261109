package com.example.blogapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

//Application - 앱에서 하나만 가능, manifest에 등록해야한다.
//process 가 구동되자 마자 가장 먼저 생성, process lifecycle과 동일 생존주기.. singleton

//hilt 이용시 최소한의 규칙..
@HiltAndroidApp
class BlogApplication: Application()