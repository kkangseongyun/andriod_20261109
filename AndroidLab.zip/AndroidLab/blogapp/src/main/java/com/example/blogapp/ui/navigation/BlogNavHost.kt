package com.example.blogapp.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.blogapp.ui.blog.detail.BlogDetailScreen
import com.example.blogapp.ui.blog.edit.BlogEditScreen
import com.example.blogapp.ui.blog.list.BlogListScreen
import com.example.blogapp.ui.home.HomeScreen
import com.example.blogapp.ui.myinfo.MyInfoScreen
import com.example.blogapp.ui.myinfo.MyInfoViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.blogapp.ui.blog.BlogViewModel

//named route : 화면을 문자열 이름으로 등록하고, 어디선가 화면전환 요청시에 name 으로 요청..
//name 만 맞으면 화면전환이 되어 아래의 sealed class가 꼭 필요한 것은 아니다..
//문자열.. 타입 안정성 문제가 있고.. 요청자의 편의성을 위한 함수도 제공하고 싶고..
//enum class와 유사한 개념이다..
sealed class Screen(val route: String){
    object Home: Screen("home")
    object MyInfo: Screen("my_info")
    object BlogList: Screen("blog_list")
    object BlogEdit: Screen("blog_edit?postId={postId}"){ //{postId} 데이터 전달..
        //화면전환 요청을 하는 곳에서 호출할 함수.. 데이터 전달에 의한 요청 name 문자열을 쉽게 만들게 하기 위해..
        fun createRoute(postId: Long? = null) =
            if(postId != null) "blog_edit?postId=$postId" else "blog_edit"
    }
    object BlogDetail: Screen("blog_detail/{postId}"){
        fun createRoute(postId: Long) = "blog_detail/$postId"
    }
}


@Composable
fun BlogNavHost(navController: NavHostController = rememberNavController()) {

    val myInfoViewModel: MyInfoViewModel = hiltViewModel()
    val blogViewModel: BlogViewModel = hiltViewModel()

    NavHost(//navController의 명령을 감지해서 화면내용을 stack정보로 관리하는 컴포저블..
        navController = navController,
        startDestination = Screen.Home.route//초기 화면..
    ){

        //화면 등록..
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = myInfoViewModel,
                onNavigateToMyInfo = { navController.navigate(Screen.MyInfo.route)},
                onNavigateToBlogList = { navController.navigate(Screen.BlogList.route)}
            )
        }
        composable(Screen.MyInfo.route) {
            MyInfoScreen(
                viewModel = myInfoViewModel,
                onBack = { navController.popBackStack()}
            )
        }
        composable(Screen.BlogList.route) {
            BlogListScreen(
                viewModel = blogViewModel,
                onNavigateToBlogDetail = { postId ->
                    navController.navigate(Screen.BlogDetail.createRoute(postId))
                },
                onNavigateToBlogEdit = {
                    navController.navigate(Screen.BlogEdit.createRoute())
                },
                onBack = { navController.popBackStack()}
            )
        }
        composable(
            route = Screen.BlogEdit.route,
            //전달 받고자 하는 데이터 명시해야 한다..
            arguments = listOf(//여기에 명시된 데이터가 화면 전환 요청시에 전달되어야 한다.
                navArgument("postId"){//route name의 {postId} 와 동일해야..
                    type = NavType.LongType
                    defaultValue = -1L//데이터 없는 경우 기본 값, 즉 이 argument는 옵셔널..
                }
            )
        ) { backStackEntry -> //실제 어디선가 화면 전환 요청이 들어오면 그 요청정보(이름, argument등)의 정보가 매개
            //변수로 전달..
            //argument 추출..
            val postId = backStackEntry.arguments?.getLong("postId") ?: -1L
            BlogEditScreen(
                viewModel = blogViewModel,
                postId = if(postId == -1L) null else postId,
                onBack = { navController.popBackStack()},
                onSaved = { navController.popBackStack()}
            )
        }

        composable(
            route = Screen.BlogDetail.route,
            arguments = listOf(
                navArgument("postId") { type = NavType.LongType }
            )
        ) { backStackEntry ->
            val postId = backStackEntry.arguments?.getLong("postId") ?: return@composable

            BlogDetailScreen(
                viewModel = blogViewModel,
                postId = postId,
                onBack = { navController.popBackStack()},
                onEdit = { navController.navigate(Screen.BlogEdit.createRoute(postId))},
                onDelete = { navController.popBackStack()}
            )
        }
    }
}










