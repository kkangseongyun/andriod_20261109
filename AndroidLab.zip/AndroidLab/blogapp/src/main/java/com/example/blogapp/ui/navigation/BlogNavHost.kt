package com.example.blogapp.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.example.blogapp.ui.blog.detail.BlogDetailScreen
import com.example.blogapp.ui.blog.edit.BlogEditScreen
import com.example.blogapp.ui.blog.list.BlogListScreen
import com.example.blogapp.ui.home.HomeScreen
import com.example.blogapp.ui.myinfo.MyInfoScreen

//자체 화면 구성목적이 아니라. 상태를 유지하고 상태값 변경시에
//각각의 컴퍼저블을 출력해서 화면 전환 효과...
@Composable
fun BlogNavHost() {
    //상태 선언.. 재구성시에 상태 데이터 유지, 화면회전시에 데이터 유지..
    var currentScreen by rememberSaveable  { mutableStateOf("home") }

    when(currentScreen){
        "home" -> HomeScreen(
            onNavigateToBlogList = { currentScreen = "blogList"},
            onNavigateToMyInfo = { currentScreen = "myInfo"}
        )
        "myInfo" -> MyInfoScreen(
            onBack = { currentScreen = "home"}
        )
        "blogList" -> BlogListScreen(
            onBack = { currentScreen = "home"},
            onNavigateToBlogDetail = { currentScreen = "blogDetail"},
            onNavigateToBlogEdit = { currentScreen = "blogEdit"}
        )
        "blogDetail" -> BlogDetailScreen(
            onBack = { currentScreen = "blogList"}
        )
        "blogEdit" -> BlogEditScreen(
            onBack =  { currentScreen = "blogList"}
        )
    }
}