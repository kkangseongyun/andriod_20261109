package com.example.blogapp.ui.blog.edit

import android.util.Log
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusModifier
import androidx.compose.ui.unit.dp

@Composable
fun BlogEditScreen(
    onBack: () -> Unit,
) {

    //유저 입력 데이터 상태로 선언. 입력 데이터로 상태를 변경해야 입력데이터 화면에 출력된다.
    //String : String + Non null type
    //String? : String + nullable
    var imageUri by rememberSaveable { mutableStateOf<String?>(null) }
    var title by rememberSaveable { mutableStateOf("")}
    var content by rememberSaveable { mutableStateOf("") }

    //유저 입력 이벤트 콜백..
    //유저 입력 데이터로 상태를 변경해서 화면에 출력되게..
    fun onTitleChange(value: String){
        title = value
    }
    fun onContentChange(value: String){
        content = value
    }

    //데이터 저장시에 호출함수..
    fun savePost(){
        Log.d("TAG", "$title, $content, $imageUri")
    }


    Scaffold(

    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                //Modifier에 padding() 이 중복선언되면 + 개념이다.
                .padding(innerPadding)//시스템 ui 에 가려지지 않게 padding 설정..
                .padding(16.dp)//개발자가 추가 여백 설정..
                .verticalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        2.dp,
                        MaterialTheme.colorScheme.outline,
                        RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "탭하여 이미지 선택",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedTextField(
                value = title,//출력 값을 상태로 지정..
                //onValueChange = {value -> ontitleChange(value)}
                ////onValueChange = {ontitleChange(it)}
                onValueChange = ::onTitleChange,//값 변경 이벤트..
                label = { Text("제목")},
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = title.isBlank(),
                supportingText = if(title.isBlank()){
                    {Text("제목을 입력하세요.")}
                }else null
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 본문 입력
            OutlinedTextField(
                value = content,
                onValueChange = ::onContentChange,
                label = { Text("본문") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 200.dp),
                minLines = 6,
                maxLines = 15
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { savePost() },
                modifier = Modifier.fillMaxWidth(),
                enabled = title.isNotBlank()
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("저장")
            }
        }
    }
}