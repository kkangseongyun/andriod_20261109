package com.example.blogapp.ui.blog.edit

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusModifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.blogapp.ui.blog.BlogViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlogEditScreen(
    viewModel: BlogViewModel,
    postId: Long?,//create - null, update - id
    onSaved: () -> Unit,//입력 데이터 저장은 이곳에서 처리할 것이다. 저장 후 화면 전환(이전화면)을 목적으로 호출
    onBack: () -> Unit,
) {

    //유저 입력 데이터 상태로 선언. 입력 데이터로 상태를 변경해야 입력데이터 화면에 출력된다.
    //String : String + Non null type
    //String? : String + nullable
    var imageUri by rememberSaveable { mutableStateOf<String?>(null) }
    var title by rememberSaveable { mutableStateOf("")}
    var content by rememberSaveable { mutableStateOf("") }

    val context = LocalContext.current
    val posts by viewModel.posts.collectAsStateWithLifecycle()

    //postId 가 not null이라면.. 기존 데이터가 준비되어 화면에 출력되게 해야 한다..
    //이곳에 상태 있다. 상태 변경시마다 이 함수는 반복 호출되어 re-composition이 된다. 매번 준비할 필요 있는가?
    LaunchedEffect(postId) {//최초 + postId가 변경되면..
        if(postId != null){
            val post = posts.find { it.id == postId }

            post?.let { //not null
                title = it.title
                content = it.content
                imageUri = it.imageUri
            } ?: {
                viewModel.loadPost(postId)
            }
        }
    }


    //유저 입력 이벤트 콜백..
    //유저 입력 데이터로 상태를 변경해서 화면에 출력되게..
    fun onTitleChange(value: String){
        title = value
    }
    fun onContentChange(value: String){
        content = value
    }

    //데이터 저장시에 호출함수..
    fun savePost(){
        Toast.makeText(context, "게시물이 저장되었습니다.", Toast.LENGTH_SHORT)
            .show()

        if(postId != null){
            viewModel.savePost(
                id = postId,
                title = title,
                content = content,
                imageUri = imageUri
            )
        }else {
            viewModel.savePost(
                id = 0,
                title = title,
                content = content,
                imageUri = imageUri
            )
        }

        //데이터 저장 후 화면 조정을 위해 호출..
        onSaved()
    }


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("새 게시물") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "뒤로가기")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { savePost() },
                        enabled = title.isNotBlank()
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "저장")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                //Modifier에 padding() 이 중복선언되면 + 개념이다.
                .padding(innerPadding)//시스템 ui 에 가려지지 않게 padding 설정..
                .padding(16.dp)//개발자가 추가 여백 설정..
                .verticalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        2.dp,
                        MaterialTheme.colorScheme.outline,
                        RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "탭하여 이미지 선택",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedTextField(
                value = title,//출력 값을 상태로 지정..
                //onValueChange = {value -> ontitleChange(value)}
                ////onValueChange = {ontitleChange(it)}
                onValueChange = ::onTitleChange,//값 변경 이벤트..
                label = { Text("제목")},
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = title.isBlank(),
                supportingText = if(title.isBlank()){
                    {Text("제목을 입력하세요.")}
                }else null
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 본문 입력
            OutlinedTextField(
                value = content,
                onValueChange = ::onContentChange,
                label = { Text("본문") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 200.dp),
                minLines = 6,
                maxLines = 15
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { savePost() },
                modifier = Modifier.fillMaxWidth(),
                enabled = title.isNotBlank()
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if(postId != null) "수정" else "저장")
            }
        }
    }
}